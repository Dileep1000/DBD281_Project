-- Cursor 1 (show supplier details and the products we have)
USE DBD281PROJECT;
GO
--------------------
DECLARE SupplierDetails CURSOR 
FOR 
SELECT SupplierID, SupplierName, Address, EmailAddress, Phone
FROM Suppliers
INNER JOIN AddressDetails ON Suppliers.AddressID = AddressDetails.AddressID
INNER JOIN ContactDetails ON Suppliers.ContactID = ContactDetails.ContactID
GROUP BY SupplierID,SupplierName, Address, EmailAddress, Phone
 
DECLARE @SupplierID int,
		@SupplierName nvarchar(50), 
        @Address nvarchar(100), 
        @EmailAddress nvarchar(30), 
        @Phone nvarchar(20)
--------------------
DECLARE cs_ProductDetails CURSOR
FOR SELECT SupplierID, ProductID, ProductCode, ProductPrice FROM Inventory
GROUP BY  SupplierID, ProductID, ProductCode, ProductPrice
DECLARE @ProductID int, @ProductCode nvarchar(40), @ProductPrice money, @PSupplierID int


OPEN SupplierDetails
FETCH NEXT FROM SupplierDetails INTO @SupplierID,@SupplierName, @Address, @EmailAddress, @Phone
WHILE @@FETCH_STATUS = 0
    BEGIN
		PRINT '======================================='
		PRINT '| Supplier Details: '
        PRINT '|'
        PRINT '| Supplier Name:  ' + @SupplierName
        PRINT '| Address:  ' + @Address
        PRINT '| Email Address:  ' + @EmailAddress
        PRINT '| Phone:  ' + @Phone 
        PRINT '|======================================'
		PRINT '|'
		PRINT '| Products Offered by Supplier: '
		PRINT '|--------------------------------------'
		OPEN cs_ProductDetails
		FETCH NEXT FROM cs_ProductDetails INTO @PSupplierID, @ProductID, @ProductCode, @ProductPrice
		WHILE @@FETCH_STATUS =0
			BEGIN
			IF(@PSupplierID=@SupplierID)
				BEGIN
				PRINT '| Product ID:  ' + CAST(@ProductID AS nvarchar(100))
				PRINT '| Product Code:  ' + @ProductCode 
				PRINT '| Product Price:  ' + CAST(@ProductPrice AS nvarchar(100))
				PRINT '|--------------------------------------'
				END
				FETCH NEXT FROM cs_ProductDetails INTO  @PSupplierID, @ProductID, @ProductCode, @ProductPrice
			END
			PRINT '======================================='
			CLOSE cs_ProductDetails
        FETCH NEXT FROM SupplierDetails INTO @SupplierID,@SupplierName, @Address, @EmailAddress, @Phone
    END
CLOSE SupplierDetails
DEALLOCATE SupplierDetails
DEALLOCATE cs_ProductDetails

GO
--Cursor 2 (Print out customer details)

DECLARE CustDetails CURSOR
FOR SELECT Customers.CustomerID, CustFirstName, CustLastName,ContactDetails.Phone,ContactDetails.EmailAddress,AddressDetails.City, AddressDetails.PostalCode, AddressDetails.Country
FROM Customers
INNER JOIN AddressDetails ON Customers.AddressID = AddressDetails.AddressID
INNER JOIN ContactDetails ON Customers.ContactID = ContactDetails.ContactID
GROUP BY Customers.CustomerID, CustFirstName, CustLastName,AddressDetails.City, AddressDetails.PostalCode, AddressDetails.Country,ContactDetails.Phone,ContactDetails.EmailAddress

DECLARE @CustomerID INT,
@CustFirstName NVARCHAR (40),
@CustLastName NVARCHAR(50),
@PhoneNumber NVARCHAR(50),
@EmailAddress NVARCHAR (50),
@City NVARCHAR (50),
@PostalCode NVARCHAR(50),
@Country NVARCHAR(50)

OPEN CustDetails
FETCH NEXT FROM CustDetails INTO @CustomerID, @CustFirstName, @CustLastName, @PhoneNumber, @EmailAddress, @City, @PostalCode, @Country
WHILE @@FETCH_STATUS = 0
BEGIN
PRINT 'Customer ID: ' + CAST(@CustomerID AS VARCHAR)
PRINT 'Customer Name: ' + @CustFirstName
PRINT 'Customer Surname: ' + @CustLastName
PRINT 'Phone Number: ' + @PhoneNumber
PRINT 'Email Address: ' + @EmailAddress
PRINT 'City: ' + @City
PRINT 'Postal Code: ' + @PostalCode
PRINT 'Country: ' + @Country
PRINT '===================================='
FETCH NEXT FROM CustDetails INTO @CustomerID, @CustFirstName, @CustLastName, @PhoneNumber, @EmailAddress, @City, @PostalCode, @Country
END
CLOSE CustDetails
DEALLOCATE CustDetails

GO
--Cursor 3(Print out employee details)
 
DECLARE EmployeeDetails CURSOR
FOR SELECT EmployeeID, EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, Address, City, PostalCode, Country, Phone
FROM Employees
INNER JOIN AddressDetails ON Employees.AddressID = AddressDetails.AddressID
INNER JOIN ContactDetails ON Employees.ContactID = ContactDetails.ContactID
GROUP BY EmployeeID, EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, Address, City, PostalCode, Country, Phone
 
DECLARE @EmployeeID INT,
@EmpFirstName nvarchar(40),
@EmpLastName nvarchar(40),
@EmpDatehired date,
@EmpSalary money,
@Address nvarchar(100),
@City nvarchar(30),
@PostalCode nvarchar(10),
@Country nvarchar(20),
@Phone nvarchar(20)
 
OPEN EmployeeDetails
FETCH NEXT FROM EmployeeDetails INTO @EmployeeID, @EmpFirstName, @EmpLastName, @EmpDateHired, @EmpSalary, @Address, @City, @PostalCode, @Country, @Phone
WHILE @@FETCH_STATUS = 0
BEGIN
PRINT '================================================'
PRINT 'Employee Details: '
PRINT ''
PRINT 'EmployeeID: ' + CAST(@EmployeeID AS varchar(100))
PRINT 'FullName: ' + @EmpFirstName + ' ' + @EmpLastName
PRINT 'DateHired: ' + CAST(@EmpDateHired AS varchar(100))
PRINT 'Salary: ' + CAST(@EmpSalary AS varchar(100))
PRINT '------------------------------------------------'
PRINT 'Employee Address Details: '
PRINT ''
PRINT 'Address: ' + @Address
PRINT 'City: ' + @City
PRINT 'PostalCode: ' + @PostalCode
PRINT 'Country: ' + @Country
PRINT 'Phone: ' + @Phone
PRINT '================================================='
FETCH NEXT FROM EmployeeDetails INTO @EmployeeID, @EmpFirstName, @EmpLastName, @EmpDateHired, @EmpSalary, @Address, @City, @PostalCode, @Country, @Phone
END
CLOSE EmployeeDetails
DEALLOCATE EmployeeDetails

GO
--Cursor 4 (Print out order details)

USE DBD281PROJECT;

DECLARE CursorCust CURSOR
FOR SELECT Customers.CustomerID, CustFirstName, CustLastName, Orders.OrderID, Transactions.TransactionType, OrderDetails.Quantity, OrderDetails.ProductPrice, Inventory.ProductCode, OrderDate
FROM Customers
INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID
INNER JOIN Transactions ON Orders.TransactionID = Transactions.TransactionID
INNER JOIN OrderDetails ON Orders.OrderID = OrderDetails.OrderID
INNER JOIN Inventory ON OrderDetails.ProductID = Inventory.ProductID
GROUP BY Customers.CustomerID, CustFirstName, CustLastName, Orders.OrderID, TransactionType, OrderDetails.Quantity, OrderDetails.ProductPrice, Inventory.ProductCode, OrderDate

DECLARE @CustomerID INT,
@CustName NVARCHAR(50),
@CustLName NVARCHAR(50),
@OrderID INT,
@TransactionType NVARCHAR(50),
@Quantity INT,
@Price MONEY,
@ProductCode NVARCHAR(50),
@OrderDate DATE

OPEN CursorCust
FETCH NEXT FROM CursorCust INTO @CustomerID,@CustName,@CustLName,@OrderID,@TransactionType, @Quantity, @Price, @ProductCode, @OrderDate
WHILE @@FETCH_STATUS = 0
BEGIN
PRINT 'Customer ID: ' + CAST(@CustomerID AS NVARCHAR)
PRINT 'First Name: ' + @CustName
PRINT 'Last Name: ' + @CustLName
PRINT 'Transaction: ' + @TransactionType
PRINT 'Order date: ' + CAST (@OrderDate AS VARCHAR)
PRINT ' '
PRINT 'Order ID: ' + CAST(@OrderID AS NVARCHAR)
PRINT 'Product Code: ' + @ProductCode
PRINT 'Quantity: ' + CAST(@Quantity AS VARCHAR)
PRINT 'Price: ' + CAST (@Price AS VARCHAR)
PRINT '=================================='
FETCH NEXT FROM CursorCust INTO @CustomerID,@CustName,@CustLName,@OrderID,@TransactionType, @Quantity, @Price, @ProductCode, @OrderDate
END
CLOSE CursorCust
DEALLOCATE CursorCust

GO
--Queries 1
 
SELECT * FROM Inventory
 
SELECT AVG(ProductPrice) AS 'Average Price',
SUM(ProductPrice) AS 'TotVal Product', COUNT(ProductID) AS 'Number of Products',
MAX(ProductPrice) AS 'Highest Price', MIN(ProductPrice) AS 'Lowest Price'
FROM Inventory
 
 
--Queries 2
 
SELECT * FROM Employees
 
SELECT EmpLastName, EmpFirstName, EmpSalary, SUM((EmpSalary*0.12)+EmpSalary) AS 'New Salary'
FROM Employees
WHERE EmpDateHired BETWEEN '2020-01-01' AND '2020-06-01'
GROUP BY EmpLastName, EmpFirstName, EmpSalary
 
 
--Queries 3
 
SELECT OrderDetails.OrderID, Inventory.ProductCode, OrderDetails.ProductPrice, OrderDetails.Quantity
FROM OrderDetails
INNER JOIN Inventory ON OrderDetails.ProductID = Inventory.ProductID
 
 
--Queries 4
 
SELECT Orders.OrderID, Customers.CustFirstName,Customers.CustLastName, Transactions.TransactionType
FROM Orders
INNER JOIN Customers ON Orders.CustomerID = Customers.CustomerID
INNER JOIN Transactions ON Orders.TransactionID = Transactions.TransactionID
 
 
--Queries 5
 
SELECT Suppliers.SupplierID, SupplierName, ProductCode, ProductPrice
FROM Suppliers
INNER JOIN Inventory ON Suppliers.SupplierID = Inventory.SupplierID
GROUP BY Suppliers.SupplierID, SupplierName, ProductCode, ProductPrice