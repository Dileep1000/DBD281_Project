SET NOCOUNT ON
GO
 
USE master
GO
if exists (select * from sysdatabases where name='DBD281PROJECT')
        drop database DBD281PROJECT
go
 
--This creates a database backup file
DECLARE @device_directory NVARCHAR(520)
SELECT @device_directory = SUBSTRING(filename, 1, CHARINDEX(N'master.mdf', LOWER(filename)) - 1)
FROM master.dbo.sysaltfiles WHERE dbid = 1 AND fileid = 1
 
EXECUTE (N'CREATE DATABASE DBD281PROJECT
  ON PRIMARY (NAME = N''DBD281PROJECT'', FILENAME = N''' + @device_directory + N'DBD281PROJECT.mdf'')
  LOG ON (NAME = N''DBD281PROJECT_Log'',  FILENAME = N''' + @device_directory + N'DBD281PROJECT.ldf'')')
go
 
if CAST(SERVERPROPERTY('ProductMajorVersion') AS INT)<1
BEGIN
  exec sp_dboption 'DBD281PROJECT','trunc. log on chkpt.','true'
  exec sp_dboption 'DBD281PROJECT','select into/bulkcopy','true'
END
ELSE ALTER DATABASE [DBD281PROJECT] SET RECOVERY SIMPLE WITH NO_WAIT
GO

set quoted_identifier on
GO
 
use "DBD281PROJECT"
SET DATEFORMAT ymd

GO
IF (SUSER_ID('systemOwner') IS NULL)
	BEGIN
	CREATE LOGIN "systemOwner" WITH PASSWORD = 'Admin1234@dbd'
	END
IF (SUSER_ID('User1') IS NULL)
	BEGIN
	CREATE LOGIN "User1" WITH PASSWORD = 'User1234@dbd'
	END

IF (USER_ID('systemOwner') IS NULL)
	BEGIN
	CREATE USER systemOwner FOR LOGIN systemOwner;
	END
IF (USER_ID('User1') IS NULL)
	BEGIN
	CREATE USER User1 FOR LOGIN User1;
	END


GO
GRANT CREATE TABLE,CREATE VIEW,CREATE PROCEDURE,CREATE RULE,BACKUP DATABASE,BACKUP LOG,SELECT,UPDATE,INSERT,DELETE TO systemOwner;
GRANT SELECT TO User1;

GO
CREATE TABLE "ContactDetails"(
    "ContactID" int NOT NULL IDENTITY(1,1),
    "Phone" nvarchar(20),
    "EmailAddress" nvarchar(30),
    CONSTRAINT "PK_ContactDetails" PRIMARY KEY CLUSTERED("ContactID"),
    CONSTRAINT chk_email check (EmailAddress like '%_@__%.__%')

)
GO
CREATE TABLE "AddressDetails"(
    "AddressID" int NOT NULL IDENTITY(1,1),
    "Address" nvarchar(100) NOT NULL,
    "City" nvarchar(30) NOT NULL,
    "PostalCode" nvarchar(10),
    "Country" nvarchar(20)
    CONSTRAINT "PK_AddressDetails" PRIMARY KEY CLUSTERED("AddressID")
)
GO

CREATE TABLE EmployeePosition
(
"PositionID" int IDENTITY (1,1) NOT NULL PRIMARY KEY,
"PositionType" VARCHAR(50),
)
GO
CREATE TABLE "Employees" (
    "EmployeeID" "int" IDENTITY (1, 1) NOT NULL ,
    "EmpLastName" nvarchar (40) NOT NULL ,
    "EmpFirstName" nvarchar (40) NOT NULL ,
    "EmpDateHired" DATE NOT NULL ,
	"EmpSalary" money,
    "ContactID" int,
    "AddressID" int,
	"PositionID" int,
    PRIMARY KEY("EmployeeID"),
	FOREIGN KEY ("PositionID") REFERENCES EmployeePosition (PositionID),
    FOREIGN KEY ("ContactID") REFERENCES ContactDetails (ContactID),
    FOREIGN KEY ("AddressID") REFERENCES AddressDetails (AddressID)
)

GO
CREATE TABLE "Suppliers"(
    "SupplierID" int IDENTITY(1,1),
    "SupplierName" nvarchar(50),
    "SuppContactName" nvarchar(30),
    "ContactID" int,
    "AddressID" int,
    PRIMARY KEY ("SupplierID"),
    FOREIGN KEY ("ContactID") REFERENCES dbo.ContactDetails("ContactID"),
    FOREIGN KEY ("AddressID") REFERENCES dbo.AddressDetails("AddressID")
)
GO
CREATE INDEX SupplierName ON Suppliers("SupplierName");
GO
CREATE TABLE "Inventory"(
    "ProductID" int NOT NULL IDENTITY(201,1),
    "ProductCode" nvarchar(20),
    "SupplierID" int,
    "ProductPrice" money,
    "ProductStock" int,
    "Discontinued" bit,
    "ReorderLevel" int,
    "Description" ntext,
    Constraint "PK_ProductID" PRIMARY KEY("ProductID"),
    FOREIGN KEY("SupplierID") REFERENCES Suppliers("SupplierID")
)
GO
CREATE INDEX "ProductCode" on Inventory(ProductCode)
GO
 
CREATE TABLE "Customers" (
    "CustomerID" int NOT NULL IDENTITY(1,1),
    "CustFirstName" nvarchar (40) NOT NULL ,
    "CustLastName" nvarchar(50) NOT NULL,
    "CustTitle" nvarchar(20),
	"CustDateOfBirth" DATE,
    "ContactID" int,
    "AddressID" int,
    PRIMARY KEY (CustomerID),
    FOREIGN KEY ("ContactID")
    REFERENCES dbo.ContactDetails ("ContactID"),
    FOREIGN KEY ("AddressID")
    REFERENCES dbo.AddressDetails ("AddressID")
)
GO
CREATE  INDEX "CustomerName" ON Customers("CustFirstName");
CREATE  INDEX "CUstomerID" ON Customers("CustomerID");
GO
CREATE TABLE "Transactions"(
    "TransactionID" int IDENTITY(1,1),
    "TransactionType" nvarchar(10),
    CONSTRAINT "PK_TransactionID" PRIMARY KEY("TransactionID")
)
GO
CREATE TABLE "Orders"(
    "OrderID" int NOT NULL IDENTITY(1,1),
    "CustomerID"  int NOT NULL,
    "TransactionID" int NOT NULL,
    "OrderDate" DATETIME NOT NULL,
    CONSTRAINT "PK_OrderID" PRIMARY KEY ("OrderID"),
    FOREIGN KEY ("CustomerID") REFERENCES Customers(CustomerID),
    FOREIGN KEY ("TransactionID") REFERENCES Transactions("TransactionID")
)
GO
CREATE TABLE "OrderDetails"(
    "OrderID" int NOT NULL,
    "ProductID" int NOT NULL,
    "ProductPrice" money,
    "Quantity" int,
    --BELOW NEEDS MORE THOUGHT
    FOREIGN KEY("ProductID") REFERENCES Inventory("ProductID"),
    FOREIGN KEY("OrderID") REFERENCES Orders("OrderID")
)
GO
CREATE TABLE "SuppPurchase"(
    "PurchaseID" int IDENTITY(101,1),
    "SupplierID" int,
    "TransactionID" int,
    "OrderDate" DATETIME,
    CONSTRAINT "PK_PurchaseID" PRIMARY KEY("PurchaseID"),
    CONSTRAINT "FK_SupplierID" FOREIGN KEY("SupplierID")
    REFERENCES Suppliers("SupplierID"),
    CONSTRAINT "FK_TransactionID" FOREIGN KEY("TransactionID")
    REFERENCES "Transactions"("TransactionID")
)
CREATE TABLE "SuppPurchaseDetails"(
    "ProductID" int,
    "PurchaseID" int,
    "Quantity" int,
    "ProductPrice" money,
    FOREIGN KEY ("ProductID") REFERENCES Inventory(ProductID),
    FOREIGN KEY ("PurchaseID") REFERENCES SuppPurchase(PurchaseID)
)

GO
INSERT INTO Transactions(TransactionType)
VALUES ('Cash')

INSERT INTO Transactions(TransactionType)
VALUES ('Debit')

INSERT INTO Transactions(TransactionType)
VALUES ('Credit')

GO
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('065-098-1231', 'PretoriaPartsTraders@Yahoo.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('069-234-9870', 'JJAutoParts@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('065-947-6321', 'AutoPartsMenlyn@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('081-321-7650', 'KoosAutoSpares@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('082-654-4370', 'QCeedAutospares@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('076-467-4209', 'QualityAutoParts@Yahoo.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('065-098-1231', 'Carspares@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('067-764-8760', 'SyedsAutoSpareParts@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('060-752-1876', 'MidasAutoSpares@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('070-543-5631', 'Autozone@gmail.com')
 
GO
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('066-091-1908', 'Markle@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('067-980-1450', 'MikeWalzowski@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('070-345-3210', 'MJackson@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('065-981-1250', 'KatieRoy@Yahoo.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('082-098-2341', 'KaitlinBal@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('070-531-9876', 'Zandre@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('060-465-1079', 'JJenkins@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('075-652-1761', 'TyreseGibson@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('065-876-9813', 'MsParker@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('076-475-1351', 'NatalieRowling81@gmail.com')
 
GO
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('067-342-1000', 'Hamilton44@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('063-762-9871', 'BritneyV@Yahoo.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('076-871-1981', 'KimiRaikonnen@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('066-371-1876', 'Cyprus10@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('062-987-5324', 'KatyPerr@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('081-098-5676', 'NeymarFereira@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('060-567-8761', 'Messi10@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('060-143-1908', 'ChrisBale@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('082-321-1908', 'Abraham@gmail.com')
 
INSERT INTO ContactDetails(Phone, EmailAddress)
VALUES ('077-344-2760', 'AmmaraKadia@Yahoo.com')
 
GO
INSERT INTO AddressDetails(Address, City, PostalCode, Country)
VALUES ('57 De Beer road', 'Pretoria East', 0986, 'South Africa')
 
INSERT INTO AddressDetails(Address, City, PostalCode, Country)
VALUES ('42 Nelson Mandela street', 'Pretoria North', 0182, 'South Africa')
 
INSERT INTO AddressDetails(Address, City, PostalCode, Country)
VALUES ('1 WaterBok street', 'Pretoria North', 0154, 'South Africa')
 
INSERT INTO AddressDetails(Address, City, PostalCode, Country)
VALUES ('35 Polka dot street', 'Pretoria', 0231, 'South Africa')
 
INSERT INTO AddressDetails(Address, City, PostalCode, Country)
VALUES ('10 Bokser street', 'Pretoria West', 0542, 'South Africa')
 
INSERT INTO AddressDetails(Address, City, PostalCode, Country)
VALUES ('10 Gautrain road', 'Pretoria East', 0120, 'South Africa')
 
INSERT INTO AddressDetails(Address, City, PostalCode, Country)
VALUES ('280 Tangerine street', 'Pretoria West', 0267, 'South Africa')
 
INSERT INTO AddressDetails(Address, City, PostalCode, Country)
VALUES ('67 Tandart street', 'Pretoria', 0871, 'South Africa')
 
INSERT INTO AddressDetails(Address, City, PostalCode, Country)
VALUES ('32 Mason road', 'Pretoria East', 0431, 'South Africa')
 
INSERT INTO AddressDetails(Address, City, PostalCode, Country)
VALUES ('57 Manhatten street', 'Pretoria', 0216, 'South Africa')
 
GO

INSERT INTO Suppliers(SupplierName, SuppContactName, ContactID, AddressID)
VALUES ('Pretoria PartsTraders', 'Parker', 1, 1)
 
INSERT INTO Suppliers(SupplierName, SuppContactName, ContactID, AddressID)
VALUES ('JJ AutoParts', 'Mikey', 2, 2)
 
INSERT INTO Suppliers(SupplierName, SuppContactName, ContactID, AddressID)
VALUES ('AutoParts Menlyn', 'John', 3, 3)
 
INSERT INTO Suppliers(SupplierName, SuppContactName, ContactID, AddressID)
VALUES ('Koos AutoSpares', 'Koos', 4, 4)
 
INSERT INTO Suppliers(SupplierName, SuppContactName, ContactID, AddressID)
VALUES ('QCeed Autospares', 'Nathan', 5, 5)
 
INSERT INTO Suppliers(SupplierName, SuppContactName, ContactID, AddressID)
VALUES ('Quality AutoParts', 'Terry', 6, 6)
 
INSERT INTO Suppliers(SupplierName, SuppContactName, ContactID, AddressID)
VALUES ('Car spares', 'Marco', 7, 7)
 
INSERT INTO Suppliers(SupplierName, SuppContactName, ContactID, AddressID)
VALUES ('Syeds AutoSpareParts', 'Cooper', 8, 8)
 
INSERT INTO Suppliers(SupplierName, SuppContactName, ContactID, AddressID)
VALUES ('Midas AutoSpares', 'Derek', 9, 9)
 
INSERT INTO Suppliers(SupplierName, SuppContactName, ContactID, AddressID)
VALUES ('Autozone', 'Dylan', 10, 10)

GO
INSERT INTO Inventory(ProductCode, SupplierID,ProductPrice, ProductStock, Discontinued, ReorderLevel, Description)
VALUES ('LS60117A', 1, 250.00, 50, 0, 30, 'Nissan plug leads')

INSERT INTO Inventory(ProductCode, SupplierID,ProductPrice, ProductStock, Discontinued, ReorderLevel, Description)
VALUES ('LS90204', 2, 230.00, 100, 0, 15, 'Plug leads vw/audi')

INSERT INTO Inventory(ProductCode, SupplierID,ProductPrice, ProductStock, Discontinued, ReorderLevel, Description)
VALUES ('MO520085', 3, 260.00, 33, 0, 40, 'Jetta2 1.8 main bearings')

INSERT INTO Inventory(ProductCode, SupplierID,ProductPrice, ProductStock, Discontinued, ReorderLevel, Description)
VALUES ('SH211', 4, 50.00, 80, 0,  40, 'Shield Diesel Injector Cleaner 350ml')
 
INSERT INTO Inventory(ProductCode, SupplierID,ProductPrice, ProductStock, Discontinued, ReorderLevel, Description)
VALUES ('SRK25', 5, 70.00, 10, 0, 20, 'Starter repair kit ren maz mits')

INSERT INTO Inventory(ProductCode, SupplierID,ProductPrice, ProductStock, Discontinued, ReorderLevel, Description)
VALUES ('SSO6T', 6, 105.00, 20, 0, 5, 'Female Torx Set')

INSERT INTO Inventory(ProductCode, SupplierID,ProductPrice, ProductStock, Discontinued, ReorderLevel, Description)
VALUES ('SS06T', 7, 175.00, 26, 0, 33, 'Male Torx Set')

INSERT INTO Inventory(ProductCode, SupplierID,ProductPrice, ProductStock, Discontinued, ReorderLevel, Description)
VALUES ( 'WM1521' , 8, 80.00, 0, 1, 0, 'Radiator hose')

INSERT INTO Inventory(ProductCode, SupplierID,ProductPrice, ProductStock, Discontinued, ReorderLevel, Description)
VALUES ('WM1655', 9, 65.00, 50, 0, 23, 'Golf Audi water flange')

INSERT INTO Inventory (ProductCode, SupplierID,ProductPrice, ProductStock, Discontinued, ReorderLevel, Description)
VALUES ('KIP028', 10, 280.00, 65, 0, 10, 'vw electrical pump')

INSERT INTO Inventory (ProductCode, SupplierID,ProductPrice, ProductStock, Discontinued, ReorderLevel, Description)
VALUES ('KIP045', 10, 580.00, 15, 0, 10, 'vw electrical pump v2')

INSERT INTO Inventory (ProductCode, SupplierID,ProductPrice, ProductStock, Discontinued, ReorderLevel, Description)
VALUES ('KIP345', 10, 4480.00, 5, 0, 10, 'vw Motor Part')

GO

INSERT INTO Customers(CustFirstName, CustLastName, CustTitle, CustDateOfBirth, ContactID, AddressID)
VALUES ('Meghan', 'Markle', 'Ms', '1990-02-10', 11, 1)
 
INSERT INTO Customers(CustFirstName, CustLastName, CustTitle, CustDateOfBirth, ContactID, AddressID)
VALUES ('Mike', 'Walzowski', 'Mr', '1994-04-14', 12, 3)
 
INSERT INTO Customers(CustFirstName, CustLastName, CustTitle, CustDateOfBirth, ContactID, AddressID)
VALUES ('Micheal', 'Jackson', 'Mr', '1980-08-23', 13, 2)
 
INSERT INTO Customers(CustFirstName, CustLastName, CustTitle, CustDateOfBirth, ContactID, AddressID)
VALUES ('Katie', 'Roy', 'Ms', '1992-01-01', 14, 6)
 
INSERT INTO Customers(CustFirstName, CustLastName, CustTitle, CustDateOfBirth, ContactID, AddressID)
VALUES ('Kaitlin', 'Bal', 'Ms', '1973-08-07', 15, 4)
 
INSERT INTO Customers(CustFirstName, CustLastName, CustTitle, CustDateOfBirth, ContactID, AddressID)
VALUES ('Zandre', 'Van Rensburg', 'Mr', '1991-12-10', 16, 10)
 
INSERT INTO Customers(CustFirstName, CustLastName, CustTitle, CustDateOfBirth, ContactID, AddressID)
VALUES ('Johnny', 'Jenkins', 'Mr', '1998-02-07', 17, 5)
 
INSERT INTO Customers(CustFirstName, CustLastName, CustTitle, CustDateOfBirth, ContactID, AddressID)
VALUES ('Tyrese', 'Gibson', 'Mr', '1980-06-19', 18, 2)
 
INSERT INTO Customers(CustFirstName, CustLastName, CustTitle, CustDateOfBirth, ContactID, AddressID)
VALUES ('Michelle', 'Parker', 'Ms', '1969-10-02', 19, 7)
 
INSERT INTO Customers(CustFirstName, CustLastName, CustTitle, CustDateOfBirth, ContactID, AddressID)
VALUES ('Natalie', 'Rowling', 'Ms', '1976-12-31', 20, 8)

GO
INSERT INTO Orders(CustomerID, TransactionID, OrderDate)
VALUES (1, 1, '2021/08/28')

INSERT INTO Orders(CustomerID, TransactionID, OrderDate)
VALUES (1, 1, '2021/08/28')

INSERT INTO Orders(CustomerID, TransactionID, OrderDate)
VALUES (2, 2, '2021/09/28')

INSERT INTO Orders(CustomerID, TransactionID, OrderDate)
VALUES (3, 1, '2021/10/10')

INSERT INTO Orders(CustomerID, TransactionID, OrderDate)
VALUES (4, 2, '2021/10/15')

INSERT INTO Orders(CustomerID, TransactionID, OrderDate)
VALUES (5, 1, '2021/10/28')

INSERT INTO Orders(CustomerID, TransactionID, OrderDate)
VALUES (6, 3, '2021/10/08')

INSERT INTO Orders(CustomerID, TransactionID, OrderDate)
VALUES (7, 1, '2021/08/10')

INSERT INTO Orders(CustomerID, TransactionID, OrderDate)
VALUES (8, 2, '2021/05/28')

INSERT INTO Orders(CustomerID, TransactionID, OrderDate)
VALUES (9, 1, '2021/10/09')

INSERT INTO Orders(CustomerID, TransactionID, OrderDate)
VALUES (10, 2, '2021/02/18')

GO
INSERT INTO OrderDetails(OrderID, ProductID, ProductPrice, Quantity)
VALUES (1, 208, 80.00, 20)
 
INSERT INTO OrderDetails(OrderID, ProductID, ProductPrice, Quantity)
VALUES (2, 202, 230.00, 8)
 
INSERT INTO OrderDetails(OrderID, ProductID, ProductPrice, Quantity)
VALUES (3, 210, 280.00, 2)
 
INSERT INTO OrderDetails(OrderID, ProductID, ProductPrice, Quantity)
VALUES (4, 201, 250.00, 10)
 
INSERT INTO OrderDetails(OrderID, ProductID, ProductPrice, Quantity)
VALUES (5, 209, 65.00, 6)
 
INSERT INTO OrderDetails(OrderID, ProductID, ProductPrice, Quantity)
VALUES (6, 208, 80.00, 7)
 
INSERT INTO OrderDetails(OrderID, ProductID, ProductPrice, Quantity)
VALUES (7, 206, 105.00, 3)
 
INSERT INTO OrderDetails(OrderID, ProductID, ProductPrice, Quantity)
VALUES (8, 204, 50.00, 40)
 
INSERT INTO OrderDetails(OrderID, ProductID, ProductPrice, Quantity)
VALUES (9, 208, 80.00, 15)
 
INSERT INTO OrderDetails(OrderID, ProductID, ProductPrice, Quantity)
VALUES (10, 203, 260.00, 9)
 
INSERT INTO OrderDetails(OrderID, ProductID, ProductPrice, Quantity)
VALUES (11, 205, 70.00, 23)

GO

INSERT INTO EmployeePosition (PositionType)
VALUES ('Director')

INSERT INTO EmployeePosition (PositionType)
VALUES ('Executive Manager')

INSERT INTO EmployeePosition (PositionType)
VALUES ('Sales Manager')

INSERT INTO EmployeePosition (PositionType)
VALUES ('Product Manager')

INSERT INTO EmployeePosition (PositionType)
VALUES ('Employee')

INSERT INTO EmployeePosition (PositionType)
VALUES ('Janitor')

GO
 
INSERT INTO Employees(EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, ContactID, AddressID, PositionID)
VALUES ('Lewis', 'Hamilton', '2020-09-20', 50000, 21, 1, 1)

INSERT INTO Employees(EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, ContactID, AddressID, PositionID)
VALUES ('Britney', 'Vettel', '2020-01-31', 35000, 22, 4, 3)

INSERT INTO Employees(EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, ContactID, AddressID, PositionID)
VALUES ('Kimi', 'Raikonnen', '2020-03-13', 40000, 23, 7, 2)

INSERT INTO Employees(EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, ContactID, AddressID, PositionID)
VALUES ('Miley', 'Cyprus', '2021-11-23', 10000, 24, 5, 6)

INSERT INTO Employees(EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, ContactID, AddressID, PositionID)
VALUES ('Katy', 'Perr', '2021-06-10', 30000, 25, 3, 3)

INSERT INTO Employees(EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, ContactID, AddressID, PositionID)
VALUES ('Neymar', 'Fereira', '2020-12-03', 10000, 26, 10, 6)

INSERT INTO Employees(EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, ContactID, AddressID, PositionID)
VALUES ('Lionel', 'Messi', '2021-09-24', 30000, 27, 9, 4)

INSERT INTO Employees(EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, ContactID, AddressID, PositionID)
VALUES ('Christian', 'Bale', '2021-06-10', 25000, 28, 6, 5)

INSERT INTO Employees(EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, ContactID, AddressID, PositionID)
VALUES ('John', 'Abraham', '2021-03-28', 25000, 29, 8, 5)

INSERT INTO Employees(EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, ContactID, AddressID, PositionID)
VALUES ('Ammara', 'Kay', '2020-12-10', 25000, 30, 2, 5)

GO

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)        
VALUES (4, 1, '2020/03/04')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (9, 1, '2020/03/27')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (2, 2, '2020/03/27')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (6, 1, '2020/07/24')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (3, 2, '2021/02/07')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (1, 2, '2021/05/02')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (5, 3, '2021/06/19')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (4, 3, '2021/07/04')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (7, 1, '2021/08/24')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (10, 1, '2021/11/08')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (2, 1, '2021/12/30')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (5, 1, '2022/01/10')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (3, 2, '2022/01/25')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (8, 3, '2022/02/07')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (6, 1, '2022/02/25')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (1, 1, '2022/03/05')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (9, 1, '2022/03/05')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (7, 1, '2022/03/05')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (10, 2, '2022/03/16')

INSERT INTO SuppPurchase(SupplierID, TransactionID, OrderDate)
VALUES (5, 1, '2022/03/16')

GO

--Trigger 1 (Display a message when a new Customer is added)

CREATE TRIGGER Cust_Trigger
ON dbo.Customers
AFTER INSERT
AS
BEGIN
DECLARE @Message VARCHAR(50) = 'Customer Record Inserted'
PRINT @Message
END

GO

--Trigger 2 (Show a message when new contact details are added)

CREATE TRIGGER ContactDetails_Trigger
ON dbo.ContactDetails
AFTER INSERT
AS
BEGIN
DECLARE @Message VARCHAR(50) = 'Record Inserted'
PRINT @Message
END

GO
 
--Trigger 3 (Prevent certain employees from accidently being given a salary thats too high)

CREATE TRIGGER Emp_Sal_Trigger
ON dbo.Employees
AFTER UPDATE
AS
BEGIN
IF((SELECT EmpSalary FROM Employees WHERE PositionID = 6) > 10000)
BEGIN
PRINT 'Salary is too high'
ROLLBACK TRANSACTION
END
ELSE
PRINT 'Salary Updated'
END
GO
 
--Trigger 4 (Prevent changes in the employee position heirarchy)
 
CREATE TRIGGER trigEmpPos
ON dbo.Employees
AFTER INSERT
AS
BEGIN
IF((SELECT PositionID FROM Inserted) > 6)
BEGIN
ROLLBACK Transaction
PRINT 'Position ID does not exist!'
END
ELSE
PRINT 'Record Inserted'
END

GO
--View 1 (All customers with their details and order details)
CREATE VIEW vCustOrders
AS
SELECT Customers.CustomerID, CustFirstName, CustLastName, TransactionType, OrderID, OrderDate
FROM Customers
INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID
INNER JOIN Transactions ON Orders.TransactionID = Transactions.TransactionID
GROUP BY Customers.CustomerID, CustFirstName, CustLastName, TransactionType, OrderID, OrderDate
 
--View 2 (Purchase Orders)
 GO

USE DBD281PROJECT;
GO
CREATE VIEW PurchaseOrders
AS
SELECT SuppPurchase.PurchaseID, SUM([SuppPurchaseDetails].Quantity * [SuppPurchaseDetails].ProductPrice) AS 'Total Order Value'
FROM SuppPurchase
INNER JOIN SuppPurchaseDetails ON SuppPurchase.PurchaseID = SuppPurchaseDetails.PurchaseID
GROUP BY SuppPurchase.PurchaseID

--View 3 (Customer Orders)
GO

CREATE VIEW vTotalValForCustOrder
AS
SELECT Customers.CustomerID, CustFirstName, CustLastName, Orders.OrderID, SUM([OrderDetails].ProductPrice * [OrderDetails].Quantity) AS 'Total Order Value'
FROM Customers
INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID
INNER JOIN OrderDetails ON Orders.OrderID = OrderDetails.OrderID
GROUP BY Customers.CustomerID, CustFirstName, CustLastName, Orders.OrderID
 
--View 4 (Employee Details)
GO

CREATE VIEW vEmployeeDetails
AS 
SELECT EmployeeID, EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, Address, City, PostalCode, Country, Phone, EmailAddress, PositionType
FROM Employees
INNER JOIN AddressDetails ON Employees.AddressID = AddressDetails.AddressID
INNER JOIN ContactDetails ON Employees.ContactID = ContactDetails.ContactID
INNER JOIN EmployeePosition ON Employees.PositionID = EmployeePosition.PositionID
GROUP BY EmployeeID, EmpFirstName, EmpLastName, EmpDateHired, EmpSalary, Address, City, PostalCode, Country, Phone, EmailAddress, PositionType
 
--View 5 (Inventory by supplier)
 GO

CREATE VIEW vInventoryDetails
AS
SELECT ProductID, ProductCode, ProductPrice, SupplierName
FROM Inventory
INNER JOIN Suppliers ON Inventory.SupplierID = Suppliers.SupplierID

--View 6 (More Customer Order Details)
GO

create view "Orders Qry" AS
SELECT Orders.OrderID, Orders.CustomerID, Orders.OrderDate, TransactionType, Customers.CustFirstName+Customers.CustLastName as 'Customer', Address, City, PostalCode, Country
FROM Customers 
INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID
INNER JOIN AddressDetails on Customers.AddressID=AddressDetails.AddressID
INNER JOIN Transactions on Orders.TransactionID=Transactions.TransactionID
GO

-- View 7 (Show all products above the average product price)
create view "Products Above Average Price" AS
SELECT Inventory.ProductCode, Inventory.ProductPrice
FROM Inventory
WHERE Inventory.ProductPrice>(SELECT AVG(ProductPrice) From Inventory)
GO

--View 8 (Show All Customers that have purchased a product in the past year)
create view "Yearly Orders" AS
SELECT DISTINCT Customers.CustomerID, Customers.CustFirstName+Customers.CustLastName as 'Customer', AddressDetails.City, AddressDetails.Country
FROM Customers 
RIGHT JOIN Orders ON Customers.CustomerID = Orders.CustomerID
RIGHT JOIN AddressDetails ON Customers.AddressID=AddressDetails.AddressID
WHERE Orders.OrderDate BETWEEN (DATEADD(YEAR, -1, GETDATE())) And GETDATE()
GO

--Stored Procedures of orders for customers

USE DBD281PROJECT;
GO
CREATE PROCEDURE CustomerOrders
AS
SELECT Customers.CustomerID, CustFirstName, CustLastName, OrderID, TransactionID, OrderDate
FROM Customers
INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID
GROUP BY Customers.CustomerID, CustFirstName, CustLastName, OrderID, TransactionID, OrderDate

GO
--Stored procedures using parameters, for orders of customers
USE DBD281PROJECT;
GO
CREATE PROCEDURE CustomerOrders1 @CustID INT
AS
SELECT Customers.CustomerID, CustFirstName, CustLastName, OrderID, TransactionID, OrderDate
FROM Customers
INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID
WHERE Customers.CustomerID = @CustID
GROUP BY Customers.CustomerID, CustFirstName, CustLastName, OrderID, TransactionID, OrderDate

GO
--Stored procedure of what products the suppliers bought

USE DBD281PROJECT;
GO
CREATE PROCEDURE SupplierPurchases
AS
SELECT Suppliers.SupplierID, SupplierName, PurchaseID, ProductID, TransactionID, OrderDate
FROM Suppliers
INNER JOIN SuppPurchase ON Suppliers.SupplierID = SuppPurchase.SupplierID
INNER JOIN Inventory ON Suppliers.SupplierID = Inventory.SupplierID
GROUP BY Suppliers.SupplierID, SupplierName, PurchaseID, ProductID, TransactionID, OrderDate




